import flask


app = flask.Flask(__name__)

@app.route("/")

def index():
  return "This runs on replit's 127.0.0.1 and 172.18.0.56 development server."

if __name__ == "__main__":
  app.run(host="0.0.0.0")